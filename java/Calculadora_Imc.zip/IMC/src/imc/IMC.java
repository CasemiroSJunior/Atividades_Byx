/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package imc;

import java.util.Scanner;

/**
 *
 * @author Etec-User
 */
public class IMC {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        float peso, altura,resultado;
        Scanner entrada_teclado = new Scanner(System.in);
        
        System.out.println("Digite a sua altura.(ex..: 1,70)");
        altura = entrada_teclado.nextFloat();
        System.out.println("Digite seu peso atual(ex..:69,2)");
        peso = entrada_teclado.nextFloat();
        resultado = (peso/(altura*altura));
        if (resultado <=18.5){
            System.out.println("Você está na classificação 'MAGREZA'. Grau de OBESIDADE 0");
        }
        if (resultado>18.5 && resultado<25.0){
            System.out.println("Você está na classificação 'NORMAL'. Grau de OBESIDADE 0");
        }
        if (resultado>25.0 && resultado<30.0){
            System.out.println("Você está na classificação 'SOBREPESO'. Grau de OBESIDADE I");
        }
        if (resultado>=30.0 && resultado<40.0){
            System.out.println("Você está na classificação 'OBESIDADE'. Grau de OBESIDADE II");
        }
        if (resultado>=40.0){
            System.out.println("Você está na classificação 'OBESIDADE GRAVE'. Grau de OBESIDADE III");
        }
        
        System.out.println("Seu IMC é de: "+resultado);
        
    }
    
}
