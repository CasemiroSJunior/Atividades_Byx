/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package javaapplication2;

import java.util.Scanner;

/**
 *
 * @author Etec-User
 */
public class JavaApplication2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        float valor_alcool, valor_gasolina, comparacao;
        Scanner entrada_teclado = new Scanner(System.in);
        
        System.out.println("Digite o valor atual do Alcool por Litro");
        valor_alcool = entrada_teclado.nextFloat();
        System.out.println("Agora informe o valor atual da Gasolina");
        valor_gasolina = entrada_teclado.nextFloat();
        comparacao = valor_alcool/valor_gasolina;
        if (comparacao <= 0.7){
        System.out.println("A melhor escolha é Alcool");
        }
        else{
        System.out.println("Gasolina é a melhor opção");
        }
        
        
        
    }
    
}
