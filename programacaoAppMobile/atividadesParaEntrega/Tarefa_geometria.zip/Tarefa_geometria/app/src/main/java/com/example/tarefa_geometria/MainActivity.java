package com.example.tarefa_geometria;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button Quadrado = findViewById(R.id.btn_quad);
        Button Retangulo = findViewById(R.id.btn_retangulo);
        Button Triangulo = findViewById(R.id.btn_triangulo);
        Button Circulo = findViewById(R.id.btn_circulo);
        Button Trapezio = findViewById(R.id.btn_trapezio);
        Button Losango = findViewById(R.id.btn_lozango);

        //Quadrado Aba   FEITO
        Quadrado.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent pg_quad = new Intent(MainActivity.this, pg_quadrado.class);
                startActivity(pg_quad);
            }
        });
        //Retangulo Aba Pronto
        Retangulo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent pg_ret = new Intent(MainActivity.this, pg_retangulo.class);
                startActivity(pg_ret);
            }
        });
        //Triangulo Aba Pronto
        Triangulo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent pg_trian = new Intent(MainActivity.this, pg_triangulo.class);
                startActivity(pg_trian);
            }
        });
        // Circulo Aba FEITO
        Circulo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent pg_circ = new Intent(MainActivity.this, pg_circulo.class);
                startActivity(pg_circ);
            }
        });
        // Losango Aba  FEITO
        Losango.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent pg_losan = new Intent(MainActivity.this, pg_losango.class);
                startActivity(pg_losan);
            }
        });
        //Trapezio Aba Pronto
        Trapezio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent pg_trap = new Intent(MainActivity.this, pg_trapezio.class);
                startActivity(pg_trap);
            }
        });
    }
}