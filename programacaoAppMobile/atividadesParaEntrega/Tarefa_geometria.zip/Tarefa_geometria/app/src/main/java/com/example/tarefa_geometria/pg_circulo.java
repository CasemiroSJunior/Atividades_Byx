package com.example.tarefa_geometria;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class pg_circulo extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pg_circulo);

        Button btn_res = findViewById(R.id.btn_resultado_circ);
        TextView Raiu = findViewById(R.id.Raio);
        TextView res = findViewById(R.id.Result_circ);
        Button voltar = findViewById(R.id.bnt_back);

        voltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent volt = new Intent(pg_circulo.this, MainActivity.class);
                startActivity(volt);
            }
        });

        btn_res.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                double raio = Double.parseDouble(Raiu.getText().toString());
                double area = ((raio*raio)*3.14);
                res.setText("A área do circulo é de: "+area+"cm²");
            }
        });



    }
}