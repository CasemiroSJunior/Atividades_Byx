package com.example.tarefa_geometria;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
;

public class pg_losango extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pg_losango);
        TextView diag_men = findViewById(R.id.los_diagonal_menor);
        TextView diag_mai = findViewById(R.id.los_diagonal_maior);
        Button btn_result = findViewById(R.id.btn_result_losango);
        TextView res = findViewById(R.id.los_result);
        Button voltar = findViewById(R.id.bnt_back);

        voltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent volt = new Intent(pg_losango.this, MainActivity.class);
                startActivity(volt);
            }
        });

        btn_result.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                double diag_menor = Double.parseDouble(diag_men.getText().toString());
                double diag_maior = Double.parseDouble(diag_mai.getText().toString());
                double area = (diag_maior*diag_menor)/2;
                res.setText("A área do losango é de: "+area+"cm²");

            }
        });


    }
}