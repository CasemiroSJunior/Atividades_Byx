package com.example.tarefa_geometria;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class pg_quadrado extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pg_quadrado);

        Button resultado = findViewById(R.id.act_btn_quad);
        TextView lado = findViewById(R.id.valor1_quad);
        TextView res = findViewById(R.id.result_quadrado);
        Button voltar = findViewById(R.id.bnt_back);

        voltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent volt = new Intent(pg_quadrado.this, MainActivity.class);
                startActivity(volt);
            }
        });

        resultado.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                double lad = Double.parseDouble(lado.getText().toString());
                double area = lad*lad;
                res.setText("Área é igual à: "+area+"cm²");
            }
        });
    }
}