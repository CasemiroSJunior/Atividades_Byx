package com.example.tarefa_geometria;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class pg_retangulo extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pg_retangulo);
        Button act_res = findViewById(R.id.btn_res_retangulo);
        TextView base = findViewById(R.id.base_retangulo);
        TextView height = findViewById(R.id.h_retangulo);
        TextView res = findViewById(R.id.res_retangulo);
        Button voltar = findViewById(R.id.bnt_back);

        voltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent volt = new Intent(pg_retangulo.this, MainActivity.class);
                startActivity(volt);
            }
        });

        act_res.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                double bas = Double.parseDouble(base.getText().toString());
                double hei = Double.parseDouble(height.getText().toString());
                double area = bas*hei;
                res.setText("A área do retangulo é de: "+area+"cm²");
            }
        });


    }
}