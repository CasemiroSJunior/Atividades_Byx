package com.example.tarefa_geometria;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import org.w3c.dom.Text;

public class pg_trapezio extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pg_trapezio);

        Button act_res = findViewById(R.id.btn_res_trap);
        TextView base_mai = findViewById(R.id.base_mai_trap);
        TextView base_men = findViewById(R.id.base_men_trap);
        TextView alt = findViewById(R.id.h_trap);
        TextView res = findViewById(R.id.res_trap);
        Button voltar = findViewById(R.id.bnt_back);

        voltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent volt = new Intent(pg_trapezio.this, MainActivity.class);
                startActivity(volt);
            }
        });

        act_res.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                double b_ma = Double.parseDouble(base_mai.getText().toString());
                double b_mn = Double.parseDouble(base_men.getText().toString());
                double altura = Double.parseDouble(alt.getText().toString());
                double area = ((b_ma+b_mn)*altura)/2;
                res.setText("O valor da área é de: "+area+"cm²");
            }
        });
    }
}