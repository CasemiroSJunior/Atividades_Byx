package com.example.tarefa_geometria;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class pg_triangulo extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pg_triangulo);

        Button act_res = findViewById(R.id.btn_res_triangulo);
        TextView alt = findViewById(R.id.h_triang);
        TextView bas = findViewById(R.id.base_triang);
        TextView res = findViewById(R.id.res_triangulo);
        Button voltar = findViewById(R.id.bnt_back);

        act_res.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                double altura = Double.parseDouble(alt.getText().toString());
                double base = Double.parseDouble(bas.getText().toString());
                double area = (altura*base)/2;
                res.setText("A área é de: "+area+"cm²");
            }
        });
        voltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent volt = new Intent(pg_triangulo.this, MainActivity.class);
                startActivity(volt);
            }
        });
    }
}