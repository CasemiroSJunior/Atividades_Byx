package com.example.calc;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        EditText n1 = findViewById(R.id.num1);
        EditText n2 = findViewById(R.id.num2);
        TextView res = findViewById(R.id.Result);
        Button mais = findViewById(R.id.soma);
        Button menos = findViewById(R.id.sub);
        Button mtp = findViewById(R.id.mult);
        Button divisao = findViewById(R.id.div);

        mais.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                float numb1 = Float.parseFloat(n1.getText().toString());
                float numb2 = Float.parseFloat(n2.getText().toString());
                float resultado = (numb1 + numb2);
                String auau = String.valueOf(resultado);
                res.setText(auau);
            }
        });

        menos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                float numb1 = Float.parseFloat(n1.getText().toString());
                float numb2 = Float.parseFloat(n2.getText().toString());
                float resultado = (numb1 - numb2);
                String auau = String.valueOf(resultado);
                res.setText(auau);
            }
        });

        mtp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                float numb1 = Float.parseFloat(n1.getText().toString());
                float numb2 = Float.parseFloat(n2.getText().toString());
                float resultado = (numb1 * numb2);
                String auau = String.valueOf(resultado);
                res.setText(auau);
            }
        });

        divisao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                float numb1 = Float.parseFloat(n1.getText().toString());
                float numb2 = Float.parseFloat(n2.getText().toString());
                float resultado = (numb1 / numb2);
                String auau = String.valueOf(resultado);
                res.setText(auau);
            }
        });
    }
}