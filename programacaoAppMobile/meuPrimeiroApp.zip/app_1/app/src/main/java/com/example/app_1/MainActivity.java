package com.example.app_1;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView text_Email = findViewById(R.id.Text_Email);
        Button lgn_btn = findViewById(R.id.button_login);
        //text_Email.setText("Email");
        text_Email.setHintTextColor(1);
        TextView nome = findViewById(R.id.Nome);

        lgn_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String nom = nome.getText().toString();
                text_Email.setText("Boa noite !! " + nom);
            }
        });
    }
}